export interface Favoriti{
  movieId: number;
  userId: number;
  id: number
}
