export interface Movie {
  poster_path: string;
  id: number;
  title: string;
}
